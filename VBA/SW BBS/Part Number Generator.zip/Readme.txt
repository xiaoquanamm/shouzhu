Simple part number generator.
Solidtec Solutions Pty. Ltd.
www.solidtec.com.au
-----------------------------------------------------------
By default, the part number generator.txt file should be placed on the root of your c: drive.  If you wish to share this over the network, please map the network drive and edit the pathToTextFile property in the .swp file to point to the network share.  The part number generator.swp file can be placed in a location of your choosing.

Pre-requisites:
-Solidworks
- Add references to the solidworks[version] type library(should be checked by default), the microsoft scripting runtime library(scrrun.dll), and 
  solidworks[version] commands type library(swcommands.tlb)
------------------------------------------------------------


bug reports: nayshil@solidtec.com.au

Agreement:
**This is being provided free of charge; Solidtec Solutions will not be held responsible for any damages or loss of data**