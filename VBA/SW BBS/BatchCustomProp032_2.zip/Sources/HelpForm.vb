﻿Public Class HelpForm
    Private Sub LabelThread_Click(sender As Object, e As EventArgs) Handles LabelThread.Click
        Process.Start("https://forum.solidworks.com/thread/229516")
    End Sub
    Private Sub LabelFifi_Click(sender As Object, e As EventArgs) Handles LabelFifi.Click
        Process.Start("https://forum.solidworks.com/people/1-8AN5QC7")
    End Sub
End Class